// This is a simple C++ program. It prints the sentence: 
// Welcome to C++ Programming.
 
#include <iostream>
 
using namespace std;

int main()
{
    cout << "Welcome to C++ Programming." << endl;

    return 0;
}
