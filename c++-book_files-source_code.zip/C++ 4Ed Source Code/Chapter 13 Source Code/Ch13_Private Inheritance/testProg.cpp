#include <iostream>
#include "baseClass.h"
  
using namespace std;

int main()
{
    derivedC ab;

    ab.three();
    cout << endl << endl;

    return 0;
}