#include <iostream>

using namespace std;
 
int main() 
{ 
    cout << "My first C++ program." << endl;
    cout << "The sum of 2 and 3 = " << 5 << endl;
    cout << "7 + 8 = " << 7 + 8 << endl;

    return 0;
} 
