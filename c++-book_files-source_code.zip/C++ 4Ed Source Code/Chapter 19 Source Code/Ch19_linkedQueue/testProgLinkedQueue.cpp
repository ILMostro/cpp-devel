//Test Program linked queue
 
#include <iostream>
#include "linkedQueue.h"
 
using namespace std;

int main()
{
    cout << "See Example 19-5." << endl;

    return 0;
}